from django.urls import path

from query_builder_app.views.query_list import query_list
from query_builder_app.views.query_list_download import query_list_download

urlpatterns = [

    path("queries", query_list_download, name="query_list_download"),
    path('queries/manager', query_list, name='query_list'),
    
]



