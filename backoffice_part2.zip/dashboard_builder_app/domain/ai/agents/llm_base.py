


import os
import psycopg2


class LlmBase:
    def connect_to(self, dbname: str):
        return psycopg2.connect(
            dbname=dbname,
            user=os.getenv("BI_USER"),
            password=os.getenv("BI_PASSWORD"),
            host=os.getenv("BI_DNS"),
            port=os.getenv("BI_PORT")
        )
    
    def connect_to_platform(self):
        return psycopg2.connect(
            dbname=os.getenv("POSTGRES_DB"),
            user=os.getenv("POSTGRES_USER"),
            password=os.getenv("POSTGRES_PASSWORD"),
            host=os.getenv("POSTGRES_DNS"),
            port=os.getenv("POSTGRES_PORT")
        )