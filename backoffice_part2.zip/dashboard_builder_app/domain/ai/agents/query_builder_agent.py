import re
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from .llm_base import LlmBase

# Load environment variables
load_dotenv()


DB_CONTEXT = """
DATABASE CONTEXT:
- **credit_status**: id (PRIMARY KEY), name, description, disabled, uuid (UNIQUE)
- **companies**: id (PRIMARY KEY), name (UNIQUE), url, tier, active, created, payroll_active, peo_company, peo_company_id, updated, logo_name, licensing_fee, unique_provider_id, white_label, worked_hours, external_id, white_label_tag, time_clock, hourly_limit_wa, timecard_connection_id, pct_hours, white_label_description, has_normal_hours
- **credits**: id (PRIMARY KEY), credit, tip, created, updated, disapproved, rating, rating_score, credit_max, instant, account_id, card_id, user_id (FOREIGN KEY REFERENCES users(id)), status_id (FOREIGN KEY REFERENCES credit_status(id)), tip_from_cashback, fee, level_id, tier_id, approval_code, transaction_id, error_message, tabapay_network_rc, deduction_check_key (UNIQUE), type, due_date, status, pending_credit, pending_fee, user_balance, paid_date, f_operation
- **users**: id (PRIMARY KEY), first_name, last_name, employment_date, cashback_balance, cashback_updated, registration_date, updated, inactive, city, state, zip_code, longitude, latitude, terms_conditions, promotional_sms, promotional_email, last_login_date, confirmed_email, cashadvance_guid (UNIQUE), users_codes_id, company_id (FOREIGN KEY REFERENCES companies(id)), admin_company, admin_multikrd, admin_peo, payroll_active, payroll_last_date, cashback_level, payroll_type, photo_name, promotional_phone_calls, last_sms_code, onboarding, cashback_historic, cashback_pending, level_id, tier_id, tier_expiration, wage_access_program, badge_points, key, payroll_frequency, connection_id, connection_data, tabapay_account_key, failed_login, admin_api, external_id, worked_hours, termination_date, end_stop_date, promotional_code, signup_date, direct_deposit, net_fees, time_management_key, provider_connections, last_extenal_token, email (UNIQUE), email_hash (UNIQUE), last_name, birthdate, street_address, address_line_2, mobile_phone, payroll_daily, payroll_hourly, payroll_salary, admin_level_1, admin_level_2, admin_report_1, admin_report_2, direct_deposit_id (UNIQUE), admin_multikrd_2, flags, customer_uuid

BUSINESS CONTEXT:
- **usuarios** = clientes, **usuario** = cliente, **empleado** = user
- **creditos** = credito = Wage Access = wage access = WA = wa = EWA
- **fee** = comision, **fees** = comisiones
- Para saber si un usuario tiene banking, revisar si el campo users.customer_uuid no es nulo.
- Para white label, revisar el campo companies.white_label_tag.
- Relaciones de tablas:
  - users.company_id = companies.id
  - credits.user_id = users.id
  - credits.status_id = credit_status.id
- **credits.status_id** valores:
  - 1: created = ACH pendiente
  - 12: failed = failed
  - 13: approved = Wage access concedido o tipo crédito
  - 14: wage_deduction = Deducción
  - 15: canceled = Cancelado
  - 16: wa_promotional_credit = WA Promotional Credit
  - 17: wa_refund = WA Refund
- **credits.instant** valores:
  - True: crédito normal
  - False: ACH
  - NULL: deducciones
- **credits.status** valores:
  - 'ach': ACH
  - 'pending': pendientes
  - 'paid': pagados
  - 'pastDue': en past due
  - 'chargedOff': charge off
  - 'not_applied': deducción no aplica status
  - 'applied': deducción aplicada
- **users.payroll_type** valores:
  - 1: Daily
  - 2: Hourly
- **credits.type** valores:
  - 'Recurrent Solid Credit': Auto wage access vía Solid
  - 'Recurrent Tabapay Credit': Auto wage access vía Tabapay
  - 'Regular ACH Credit': ACH vía Tabapay
  - 'Regular Solid Credit': Instantáneo vía Solid
  - 'Regular Tabapay Credit': Instantáneo vía Tabapay
  - 'wage_access': Sin catalogar, pudieron ser Auto wage access o instantáneo, ambos vía Tabapay
""" 



class QueryBuilderAgent(LlmBase):
    def __init__(self, model="gpt-3.5-turbo-0125", session_id=None, user_id=None, execute_actions_tool=True):
        self.session_id = session_id
        self.user_id = user_id
        self.fields_list = None
        self.llm = ChatOpenAI(model=model)
        if execute_actions_tool:
            self.llm_with_tools = self.llm.bind_tools([self.execute_actions_tool])
        else:
            self.llm_with_tools = self.llm.bind_tools([self.test_query])

    def save_metadata(self, query, fields_list=None):
        """Callback to update the last executed query."""
        self.fields_list = fields_list

    def fix_query_callback(self, query, context, exception_message):
        """Fixes an SQL query with specific context."""
        try:
            INSTRUCTIONS = (
                '- **Fix the SQL query according to the provided context:**\n'
                '1. Use the schema in the "DATABASE CONTEXT" section.\n'
                '2. Ensure that the fields are correct and in the correct order.\n'
                '3. Ensure that the tables and fields exist in the database.\n'
                '4. Ensure that the relationships between tables are correct.\n'
                '5. Ensure that the "GROUP BY" section has the correct fields.\n'
                '6. Check the exception message to fix the query.\n'
                '- **Exception message:**\n' + exception_message + '\n' +
                DB_CONTEXT + '\n' + context + '\n'
                'Bad SQL Query:\n' + query + '\n\n'
            )

            sql_agent = SQLAgent(session_id=self.session_id, user_id=self.user_id, execute_actions_tool=False)
            response = sql_agent.fix_query(INSTRUCTIONS)
        except Exception as e:
            print(f'\033[91m{str(e)}\033[0m')
            response = self.fix_query_callback(response['query'], context, str(e))
        return {
            "query": response['query'],
            "data": response['data']
        }

    @staticmethod
    @tool
    def execute_actions_tool(
        query, 
        session_id, 
        connection_platform, 
        connection_dashboard_builder, 
        save_metadata, 
        fields_list, 
        explain, 
        datatables_columns_config, 
        summary_context, 
        fix_query_callback, 
        save_session_context
    ):
        """Executes an SQL query in the PostgreSQL database and returns the results."""
        save_metadata(query, fields_list)
        try:
            with connection_platform.cursor() as cursor:
                cursor.execute(query)
                data = cursor.fetchall()
                final_query = query
        except Exception as e:
            print(f'\033[91m{str(e)}\033[0m')

            save_session_context(
                session_id=session_id, 
                chat_record=query, 
                connection=connection_dashboard_builder, 
                author='Model',
                close_connection=False
            )
            full_message = str(e)
            
            match = re.search(r"^(.*?)(?:\s+LINE\s+\d+:)?$", full_message, re.DOTALL)
            if match:
                exception_message = match.group(1)
            else:
                exception_message = full_message

            save_session_context(
                session_id=session_id, 
                chat_record=exception_message, 
                connection=connection_dashboard_builder, 
                author='Database'
            )
            response = fix_query_callback(query, summary_context, str(e))
            final_query = response['query']
            data = response['data']
        finally:
            connection_platform.close()

        return {
            "data": data,
            "fields_list": fields_list,
            "query": final_query,
            "explain": explain,
            "datatables_columns_config": datatables_columns_config,
            "summary_context": summary_context
        }


    def get_data(self, user_request):

        chat_history = self.retrieve_session_context(session_id=self.session_id, connection=self.connect_to('dashboard_builder'))

        self.save_session_context(
            session_id=self.session_id, 
            chat_record=user_request, 
            connection=self.connect_to('dashboard_builder'),
            author='Users'
        )
        user_instructions = "\n\nNEXT USER INSTRUCTIONS:\n**(" + user_request + ")**\n\n"

        if chat_history:
            instruction_1 = (
                "INSTRUCTIONS:\n"
                "1. Update the last generated query and execute it with 'execute_actions_tool' as per user requirements, using the schema in the 'DATABASE CONTEXT' section.\n"
            )
            chat_history = "CHAT CONTEXT (HISTORY):\n" + chat_history
        else:
            instruction_1 = (
                "INSTRUCTIONS:\n"
                "1. Create a new query and execute it with 'execute_actions_tool' as per user requirements, using the schema in the 'DATABASE CONTEXT' section.\n"
            )

        instructions = instruction_1 + (
            "2. Use the 'execute_actions_tool' with the parameters:\n"
            "     - **fields_list**: The list of fields.\n"
            "     - **explain**: Your SQL explanation.\n"
            "     - **datatables_columns_config**: The DataTables columns object with obtained fields (data and title),\n"
            "     for title, use user-friendly names. Example: [{ data: 'id', title: 'ID' }, { data: 'email', title: 'Email' }...].\n"
            "     - **summary_context**: A summary of the conversation context.\n"
            "3. **IMPORTANT:** Do not ask for confirmation or respond in 'content', execute the instructions directly without confirmation, always use your 'execute_actions_tool'.\n"
            "4. Respond in the language the user uses in their requirements.\n"
            "5. **IMPORTANT:** Always use the following tool: 'execute_actions_tool'.\n"
            "6. **IMPORTANT:** Use the following tool: 'execute_actions_tool'.\n"
        )

        complete_context_with_query = DB_CONTEXT + "\n" + (chat_history if chat_history else "") + user_instructions + instructions

        print('............................................................')
        print(f'\033[92m{complete_context_with_query}\033[0m')
        print('............................................................')

        def transform_input(x):
            try:
                if not x.tool_calls:
                    raise ValueError(x.content)
                query = x.tool_calls[0]['args']["query"]
                fields_list = x.tool_calls[0]['args']["fields_list"]
                explain = x.tool_calls[0]['args']["explain"]
                datatables_columns_config = x.tool_calls[0]['args']["datatables_columns_config"]
                summary_context = x.tool_calls[0]['args']["summary_context"]
                return {
                    "query": query,
                    "session_id": self.session_id,  
                    "connection_platform": self.connect_to_platform(),
                    "connection_dashboard_builder": self.connect_to('dashboard_builder'),
                    "save_metadata": self.save_metadata,
                    "fields_list": fields_list,
                    "explain": explain,
                    "datatables_columns_config": datatables_columns_config,
                    "summary_context": summary_context,
                    "fix_query_callback": self.fix_query_callback,
                    "save_session_context": self.save_session_context
                }
            except Exception as e:
                print(f'\033[91m{str(e)}\033[0m')

        chain = self.llm_with_tools | transform_input | self.execute_actions_tool
        results = chain.invoke(complete_context_with_query)


        self.save_session_context(
            session_id=self.session_id, 
            chat_record= results['query'], 
            connection=self.connect_to('dashboard_builder'), 
            author='Model'
        )

        data_list_dict = [dict(zip(results['fields_list'], record)) for record in results['data']]

        print(f'\033[92m{results["query"]}\033[0m')
        return {
            "data": data_list_dict,
            "fields_list": results['fields_list'],
            "query": results['query'],
            "explain": results['explain'],
            "datatables_columns_config": results['datatables_columns_config'],
            "data_tupla": results['data']
        }

    def save_session_context(self, session_id, chat_record, connection, author, close_connection=False):
        """Saves the session context in the database."""
        try:
            new_data = f"\n- **{author}**: {chat_record}"
            with connection.cursor() as cursor:
                cursor.execute("INSERT INTO session_context_query (id_session, context) VALUES (%s, %s) ON CONFLICT (id_session) DO UPDATE SET context = session_context_query.context || %s", 
                               (session_id, new_data, new_data))
                connection.commit()
        except Exception as e:
            print(str(e))
        finally:
            if close_connection:
                connection.close()

    def retrieve_session_context(self, session_id, connection):
        """Retrieves the session context from the database."""
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT context FROM session_context_query WHERE id_session = %s", (session_id,))
                result = cursor.fetchone()
                return result[0] if result else None
        finally:
            connection.close()

    @staticmethod
    @tool
    def test_query(query, connection_platform):
        """Executes an SQL query in the PostgreSQL database and returns the results."""
        with connection_platform.cursor() as cursor:
            cursor.execute(query)
            data = cursor.fetchall()
            return {
                "data": data,
                "query": query
            }

    def fix_query(self, instructions):
        complete_context_with_query = instructions + (
            "7. Use the 'test_query' tool to verify the query with the parameters:\n"
            "     - **query**: Corrected query.\n"
            "8. Do not ask for confirmation in 'content', execute the instructions directly without confirmation, always use your 'test_query' tool.\n"
        )

        print('............................................................')
        print(f'\033[92m{complete_context_with_query}\033[0m')
        print('............................................................')

        def transform_input(x):
            try:
                if not x.tool_calls:
                    raise ValueError(x.content)
                query = x.tool_calls[0]['args']["query"]
                return {
                    "query": query,
                    "connection_platform": self.connect_to_platform()
                }
            except Exception as e:
                print(f'\033[91m{str(e)}\033[0m')

        chain = self.llm_with_tools | transform_input | self.test_query
        return chain.invoke(complete_context_with_query)