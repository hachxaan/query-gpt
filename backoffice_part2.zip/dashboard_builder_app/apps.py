from django.apps import AppConfig


class DashboardBuilderAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dashboard_builder_app'
