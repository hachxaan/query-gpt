class ApplicationDomain:
    """ApplicarionDomain"""
