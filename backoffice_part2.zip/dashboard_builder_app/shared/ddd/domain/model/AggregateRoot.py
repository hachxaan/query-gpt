from .EntityRoot import EntityRoot


class AggregateRoot(EntityRoot):
    pass
