class DomainService:
    """DomainService"""
